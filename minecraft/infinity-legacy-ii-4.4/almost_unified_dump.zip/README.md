# Recipe dump reference

Almost Unified dump from **Infinity Legacy II v4.4** (Minecraft **1.21.1**, NeoForge).

Unzip `almost_unified_dump.zip` for the full lists (`recipes_after`, `recipes_before`, tags, duplicates, unification). `overview.txt` is the count table.

This is pack reference data for Uncraftit, not part of the runtime mod.
